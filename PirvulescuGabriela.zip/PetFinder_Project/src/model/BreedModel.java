package model;

public class BreedModel {
    private String breedName;
    private int animalTypeID;
    private String description;

    public String getBreedName() {
        return breedName;
    }

    public void setBreedName(String breedName) {
        this.breedName = breedName;
    }

    public int getAnimalTypeID() {
        return animalTypeID;
    }

    public void setAnimalTypeID(int animalTypeID) {
        this.animalTypeID = animalTypeID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
